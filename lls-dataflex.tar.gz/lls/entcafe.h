open gci
open fazenda
open lote1

outfile "entcafe.txt"

integer sacasnota sacas
number pesonota

move 0 to total
move 0 to counter
move 0 to sacasnota
move 0 to pesonota
move 0 to sacas

clear gci
move data to gci.data

iniciogci:
find gt gci.data
[~found] goto fimgci
	
	calc (counter + 1) to counter
	
	print counter to tela.9
	
	if gci.data lt data goto iniciogci
	
	clear fazenda
	move gci.dono to fazenda.dono
	
	iniciogci2:
	find gt fazenda.dono
	[~found] goto fimgci2
		if gci.faz ne fazenda.codigo goto iniciogci2
		
	fimgci2:
	
	move gci.qnota to sacasnota
	move gci.pnota to pesonota
	
	move gci.des to sacas
	
	if sacasnota eq 0 begin
	
		clear lote1
		move gci.codigo to lote1.codigo
		find eq lote1.codigo
		[found] begin
			move lote1.descarrego to sacasnota
			move (sacasnota * 60.5) to pesonota
		end
	
	end
	
	if sacas eq 0 move sacasnota to sacas
	
	clear lote1
	
		print gci.recnum  	   	to entcafe.1		// id
		print gci.data  	   	to entcafe.2		// data
		print gci.codigo     	to entcafe.3		// lote
		print gci.nf     		to entcafe.4		// nota
		print gci.valor       	to entcafe.5		// valor nota
		print sacasnota			to entcafe.6		// sacas nota
		print pesonota	    	to entcafe.7		// peso nota
		print gci.placa     	to entcafe.8		// placa
		print gci.tik     		to entcafe.9		// ticket
		print sacas				to entcafe.10		// sacas
		print gci.pesooriginal 	to entcafe.11		// peso
		print gci.obs     		to entcafe.12		// obs
		print fazenda.recnum	to entcafe.13		// fazenda_id 
		
		calc (total + 1) to total
		
		print total to tela.8
		
		output entcafe

goto iniciogci

fimgci:
close gci
close fazenda
close lote1
