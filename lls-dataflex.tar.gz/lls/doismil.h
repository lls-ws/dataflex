/*
////////////////////// mudando data  /////////////////////////////
///////////////////// atualizado em 10/05/2010 ///////////////////
date dato
sysdate dato
integer mes ano_atual
string dia
left dato to dia 2
mid dato to mes 2 4
right dato to ano_atual 3
calc (ano_atual + 1900) to ano_atual
string data
move "" to data
append data dia "/" mes "/" ano_atual
move data to dato
//////////////////// fim /////////////////////////////////////////