open servico1
open fazenda
open tabela

integer idtabela

outfile "servcafe.txt"

move 0 to total
move 0 to counter
move 0 to idtabela

clear servico1
move data to servico1.data

inicioservico1:
find gt servico1.data
[~found] goto fimservico1

	calc (counter + 1) to counter
	
	print counter to tela.31
	
	if servico1.data lt data goto inicioservico1
	
	clear fazenda
	move servico1.cliente to fazenda.dono
	
	inicioservico12:
	find gt fazenda.dono
	[~found] goto inicioservico1
		if servico1.faz ne fazenda.codigo goto inicioservico12  
		
	clear tabela
	move servico1.servico to tabela.flavio
	find eq tabela.flavio
	[~found] move 16 to idtabela
	[found] move tabela.recnum to idtabela
	
		print servico1.data		   	to servcafe.1
		print servico1.lote		   	to servcafe.2
		print servico1.quant     	to servcafe.3
		print servico1.total     	to servcafe.4
		print servico1.obs1       	to servcafe.5
		print servico1.obs2			to servcafe.6
		
		if servico1.flag eq "*" begin
		
			print "Y" to servcafe.7
		end
		
		if servico1.flag ne "*" begin
		
			print "N" to servcafe.7
		end
		
		print fazenda.recnum		to servcafe.8
		print idtabela				to servcafe.9
		
		calc (total + 1) to total
		
		print total to tela.30
		
		output servcafe

goto inicioservico1

fimservico1:
close servico1
close fazenda
close tabela
