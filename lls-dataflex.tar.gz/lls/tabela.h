open tabela

outfile "tabela.txt"

move 0 to total

iniciotab:
find gt tabela.recnum
[~found] goto fimtab

	print tabela.recnum	       to tab.1
	print tabela.descricao     to tab.2
	print tabela.valor1        to tab.3
	
	calc (total + 1) to total
	
	print total to tela.2
	
	output tab

goto iniciotab

fimtab:
close tabela
