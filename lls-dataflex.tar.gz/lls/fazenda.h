open fazenda
open cliente

outfile "fazenda.txt"

move 0 to total

iniciofaz:
find gt fazenda.recnum
[~found] goto fimfaz
	
	clear cliente
	move fazenda.dono to cliente.codigo
	find eq cliente.codigo
	[found] begin
	
		print cliente.recnum		to faz.1
		print fazenda.recnum        to faz.2
		print fazenda.nome	        to faz.3
		print fazenda.endereco      to faz.4
		print fazenda.cidade        to faz.5
		print fazenda.uf	        to faz.6
		print fazenda.cep	        to faz.7
		print fazenda.cgc	        to faz.8
		print fazenda.insc	        to faz.9
		
		calc (total + 1) to total
		
		print total to tela.5
		
		output faz

	end

goto iniciofaz

fimfaz:
close fazenda
close cliente
