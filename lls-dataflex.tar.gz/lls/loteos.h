open lote1
open tipo
open gs

outfile "loteosc.txt"

move 0 to idtipo
move 0 to idgs
move 0 to total
move 0 to counter

clear lote1
move data to lote1.data

inicioloteosc:
find gt lote1.data
[~found] goto fimloteosc
	
	calc (counter + 1) to counter
	
	print counter to tela.17
	
	if lote1.data lt data goto inicioloteosc
	if lote1.tipo eq 0 goto inicioloteosc
	if lote1.codigo eq lote1.de goto inicioloteosc
	
	clear gs
	move lote1.de to gs.numero
	find eq gs.numero
	[~found] goto inicioloteosc
	[found] move gs.recnum to idgs
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[~found] goto inicioloteosc
	[found] move tipo.recnum to idtipo
	
		print lote1.recnum				to loteosc.1		// id
		print lote1.codigo				to loteosc.2		// lote
		print lote1.descarrego			to loteosc.3		// sacas
		print lote1.pesooriginal       	to loteosc.4		// peso
		print lote1.qtd					to loteosc.5		// saldo sacas
		print lote1.peso	    		to loteosc.6		// saldo peso
		print lote1.red	     			to loteosc.7		// armazem
		print lote1.quadra  			to loteosc.8		// pilha
		print idtipo					to loteosc.9		// peneira_id
		print idgs						to loteosc.10		// oscafe_id
		
		calc (total + 1) to total
		
		print total to tela.16
		
		output loteosc

goto inicioloteosc

fimloteosc:
close lote1
close tipo
close gs
