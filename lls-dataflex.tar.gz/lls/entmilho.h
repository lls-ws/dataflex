open entmilho
open fazenda
open umidade

outfile "entmilho.txt"

move 0 to total
move 0 to counter

integer idumi

inicioentmilho:
find gt entmilho.recnum
[~found] goto fimentmilho
	
	calc (counter + 1) to counter
	
	print counter to tela.14
	
	if entmilho.data lt data goto inicioentmilho
	
	clear fazenda
	move entmilho.cliente to fazenda.dono
	
	inicioentmilho2:
		find gt fazenda.dono
		[~found] goto fimentmilho2
		if entmilho.faz ne fazenda.codigo goto inicioentmilho2  
		
	fimentmilho2:
	
	clear umidade
	move entmilho.umidade to umidade.codigo
	find eq umidade.codigo
	[~found] move 1 to idumi
	[found] move umidade.recnum to idumi
	
		print entmilho.data     	to entmil.1
		print entmilho.laudo     	to entmil.2
		print entmilho.tiket     	to entmil.3
		print entmilho.placa       	to entmil.4
		print entmilho.bruto		to entmil.5
		print entmilho.impureza    	to entmil.6
		print entmilho.chocho     	to entmil.7
		print entmilho.quirela     	to entmil.8
		print entmilho.liquido     	to entmil.9
		print entmilho.limpeza     	to entmil.10
		print entmilho.secagem     	to entmil.11
		print entmilho.carga     	to entmil.12
		print entmilho.outras     	to entmil.13
		print entmilho.total       	to entmil.14
		print entmilho.obs	     	to entmil.15
		print entmilho.cilo     	to entmil.16
		print entmilho.fat	     	to entmil.17
		print fazenda.recnum		to entmil.18
		print idumi					to entmil.19
		
		calc (total + 1) to total
		
		print total to tela.11
		
		output entmil

goto inicioentmilho

fimentmilho:
close entmilho
close fazenda
close umidade
