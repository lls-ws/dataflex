open saidas
open gsbx
open lote1

outfile "sailote.txt"

integer idgsbx

move 0 to idgsbx
move 0 to idlote

move 0 to total
move 0 to counter

clear saidas
move data to saidas.data

iniciosaidas:
find gt saidas.data
[~found] goto fimsaidas
	
	calc (counter + 1) to counter
	
	print counter to tela.21
	
	if saidas.data lt data goto iniciosaidas
	
	clear gsbx
	move saidas.saida to gsbx.numero
	find eq gsbx.numero
	[~found] goto iniciosaidas
	[found] move gsbx.recnum to idgsbx
	
	clear lote1
	move saidas.lote to lote1.codigo
	find eq lote1.codigo
	[~found] goto iniciosaidas
	[found] move lote1.recnum to idlote
	
		print idgsbx			  	   	to sailote.1		// saicafe_id
		print idlote	  	   			to sailote.2		// lote_id
		print saidas.qtd     			to sailote.3		// sacas
		print saidas.liquido       		to sailote.4		// peso
		
		calc (total + 1) to total
		
		print total to tela.20
		
		output sailote

goto iniciosaidas

fimsaidas:
close saidas
close gsbx
close lote1
