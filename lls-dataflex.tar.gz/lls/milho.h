open milho
open fazenda

outfile "milho.txt"

move 0 to total

iniciomil:
find gt milho.recnum
[~found] goto fimmil
	
	clear fazenda
	move milho.cliente to fazenda.dono
	
	iniciomil2:
		find gt fazenda.dono
		[~found] goto fimmil2
		if milho.faz ne fazenda.codigo goto iniciomil2  
		
	fimmil2:
	
		print fazenda.recnum	to mil.1
		print milho.bruto		to mil.2
		print milho.peso        to mil.3
		print milho.dataent     to mil.4
		print milho.quant       to mil.5
		print milho.datasai     to mil.6
		print milho.total       to mil.7
		print milho.ultimo		to mil.8
		
		calc (total + 1) to total
		
		print total to tela.10
		
		output mil

goto iniciomil

fimmil:
close milho
close fazenda
