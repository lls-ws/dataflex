open peso

outfile "ticket.txt"

clear peso
move 999999 to peso.numero
find lt peso.numero
	
print peso.numero to tela.2

print peso.numero to ticket.1		// ticket

output ticket

clear peso

outfile "peso.txt"

number tara bruto
string placa

move 0 to total
move 0 to counter

clear peso
move data to peso.data

iniciopeso:
find gt peso.data
[~found] goto fimpeso
	
	calc (counter + 1) to counter
	
	print counter to tela.4
	
	if peso.data lt data goto iniciopeso
	
	move peso.placa to placa
	
	if placa eq "TRATOR" move "TRA0000" to placa
	if placa eq "X" move "XXX0000" to placa
	
	move peso.tara to tara
	move peso.bruto to bruto
	
	if peso.liquido eq 0 begin
		move peso.primeiro to bruto
		if peso.tipo eq "GE" move peso.primeiro to tara
	end
	
	print peso.numero  	   	to pesagem.1		// ticket
	print peso.data	    	to pesagem.2		// data
	print peso.hora	    	to pesagem.3		// hora
	print peso.minuto	    to pesagem.4		// minuto
	print peso.data2	   	to pesagem.5		// dataFinalizado
	print peso.hora2	   	to pesagem.6		// horaFinalizado
	print peso.minuto2	    to pesagem.7		// minutoFinalizado
	print peso.placa     	to pesagem.8		// placa
	print peso.mercadoria   to pesagem.9		// produto
	print tara				to pesagem.10		// tara
	print bruto    			to pesagem.11		// bruto
	print peso.liquido     	to pesagem.12		// liquido
	print peso.terceiro1	to pesagem.13		// produtor
	print peso.motorista	to pesagem.14		// motorista
	print peso.destino     	to pesagem.15		// obs
	print peso.fazenda		to pesagem.16		// fazenda_id 
	
	calc (total + 1) to total
	
	print total to tela.3
	
	output pesagem

goto iniciopeso

fimpeso:
close peso
