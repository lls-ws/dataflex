open trans
open fazenda

outfile "tracafe.txt"

move 0 to total
move 0 to counter

clear trans
move data to trans.dato

iniciotrans:
find gt trans.dato
[~found] goto fimtrans
	
	calc (counter + 1) to counter
	
	print counter to tela.23
	
	if trans.dato lt data goto iniciotrans
	
	clear fazenda
	move trans.dono to fazenda.dono
	
	iniciotrans2:
	find gt fazenda.dono
	[~found] goto fimtrans2
		if trans.faz ne fazenda.codigo goto iniciotrans2
		
	fimtrans2:
	
		print trans.recnum  	   	to tracafe.1		// id
		print trans.data  	   		to tracafe.2		// data
		print trans.nro		     	to tracafe.3		// lote
		print trans.qtd     		to tracafe.4		// sacas
		print trans.peso       		to tracafe.5		// peso
		print trans.obs1     		to tracafe.6		// obs
		print fazenda.recnum		to tracafe.7		// fazenda_id 
		
		calc (total + 1) to total
		
		print total to tela.22
		
		output tracafe

goto iniciotrans

fimtrans:
close trans
close fazenda
