open trans1
open trans
open lote1

outfile "tralote.txt"

move 0 to idtrans
move 0 to idlote

move 0 to total
move 0 to counter

clear trans1
move data to trans1.data

iniciotrans1:
find gt trans1.data
[~found] goto fimtrans1
	
	calc (counter + 1) to counter
	
	print counter to tela.25
	
	if trans1.data lt data goto iniciotrans1
	
	clear trans
	move trans1.saida to trans.nro
	find eq trans.nro
	[~found] goto iniciotrans1
	[found] move trans.recnum to idtrans
	
	clear lote1
	move trans1.lote to lote1.codigo
	find eq lote1.codigo
	[~found] goto iniciotrans1
	[found] move lote1.recnum to idlote
	
		print idtrans			  	   	to tralote.1		// tracafe_id
		print idlote	  	   			to tralote.2		// lote_id
		print trans1.qtd     			to tralote.3		// sacas
		print trans1.liquido       		to tralote.4		// peso
		
		calc (total + 1) to total
		
		print total to tela.24
		
		output tralote

goto iniciotrans1

fimtrans1:
close trans1
close trans
close lote1
