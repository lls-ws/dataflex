open lotao
move 0 to qtd
move 0 to qtd2

print "lotao" to tela.4
print qtd to tela.5
print qtd to tela.6

inicio_lotao:
find gt lotao.recnum
[not found] goto fim_lotao
    inkey$ tecla
    if tecla eq "q" goto termina
    
    if lotao.data gt tela.1 begin
	calc (qtd2 + 1) to qtd2
	print qtd2 to tela.6
	goto inicio_lotao
    end    
    
    reread
	calc (qtd + 1) to qtd
	print qtd to tela.5
	delete lotao
    unlock
    
goto inicio_lotao

fim_lotao: