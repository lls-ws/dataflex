open servico4
open fazenda
open tabela
open cliente

outfile "servico4.txt"

move 0 to total
move 0 to counter

integer idtabela idfaz

string dataserv

move "01/01/2015" to dataserv

inicioservico4:
find gt servico4.recnum
[~found] goto fimservico4

	calc (counter + 1) to counter
	
	print counter to tela.14
	
	if servico4.data lt dataserv goto inicioservico4
	
	clear cliente
	move servico4.cliente to cliente.codigo
	find eq cliente.codigo
	[found] move cliente.codigo to idfaz
	[~found] move 177 to idfaz

	clear fazenda
	move servico4.cliente to fazenda.dono
	
	inicioservico42:
		find gt fazenda.dono
		[~found] goto fimservico42
			if servico4.faz ne fazenda.codigo goto inicioservico42  
			
				move fazenda.recnum to idfaz
		
	fimservico42:
	
	clear tabela
	move servico4.servico to tabela.flavio
	find eq tabela.flavio
	[~found] move 20 to idtabela
	[found] move tabela.recnum to idtabela
	
		print servico4.data		   	to servmil.1
		print servico4.dataemite   	to servmil.2
		print servico4.quant     	to servmil.3
		print servico4.total     	to servmil.4
		print servico4.obs1       	to servmil.5
		print servico4.obs2			to servmil.6
		
		if servico4.flag eq "*" begin
		
			print "Y" to servmil.7
		end
		
		if servico4.flag ne "*" begin
		
			print "N" to servmil.7
		end
		
		print idfaz					to servmil.8
		print idtabela				to servmil.9
		
		calc (total + 1) to total
		
		print total to tela.13
		
		output servmil

goto inicioservico4

fimservico4:
close servico4
close fazenda
close tabela
close cliente
