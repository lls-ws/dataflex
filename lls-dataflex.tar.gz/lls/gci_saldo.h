open gci
clear gci
move tela.1 to gci.dono

inicio_gci:
find gt gci.dono
[~found] goto inicio
            if gci.flag eq "*"    goto inicio
            if gci.data gt tela.6 goto inicio
            if gci.dono ne tela.1 goto inicio22
            if gci.faz  ne tela.3 goto inicio
            if gci.qtd eq 0       goto inicio
