open fazenda

outfile "cafe.txt"

move 0 to total
move 0 to counter

clear fazenda

inicio_cafe:
find gt fazenda.recnum
[~found] goto fim_cafe
	
	calc (counter + 1) to counter
	
	print counter to tela.29
	
	if (fazenda.saca + fazenda.estoque) eq 0 goto inicio_cafe
	if fazenda.dataescri eq "" goto inicio_cafe
	
	print fazenda.recnum 		to cafe.1
	print fazenda.estoque 		to cafe.2
	print fazenda.dataescri 	to cafe.3
	output cafe
	
	calc (fazenda.estoque + total) to total
	print total to tela.28
	
goto inicio_cafe

fim_cafe:
close fazenda
