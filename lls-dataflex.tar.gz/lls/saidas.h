open saidas
move 0 to qtd
move 0 to qtd2

print "saidas" to tela.4
print qtd to tela.5
print qtd to tela.6

inicio_saidas:
find gt saidas.recnum
[not found] goto fim_saidas
    inkey$ tecla
    if tecla eq "q" goto termina
    
    if saidas.data gt tela.1 begin
	calc (qtd2 + 1) to qtd2
	print qtd2 to tela.6
	goto inicio_saidas
    end    
    
    reread
	calc (qtd + 1) to qtd
	print qtd to tela.5
	delete saidas
    unlock
    
goto inicio_saidas

fim_saidas: