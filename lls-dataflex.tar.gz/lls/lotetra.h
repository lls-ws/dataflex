open lote1
open tipo
open trans

outfile "lotetra.txt"

move 0 to idtipo
move 0 to idtrans
move 0 to total
move 0 to counter

clear lote1
move data to lote1.data

iniciolotetra:
find gt lote1.data
[~found] goto fimlotetra
	
	calc (counter + 1) to counter
	
	print counter to tela.27
	
	if lote1.data lt data goto iniciolotetra
	if lote1.codigo eq lote1.de goto iniciolotetra
	
	clear trans
	move lote1.de to trans.nro
	find eq trans.nro
	[~found] goto iniciolotetra
	[found] move trans.recnum to idtrans
	
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[found] move tipo.recnum to idtipo
	[~found] begin 
	
		clear tipo
		move lote1.peneira to tipo.nome
		
		iniciotipo:
		find gt tipo.recnum
		[~found] goto iniciolotetra
			
			if lote1.peneira ne tipo.nome goto iniciotipo
			
			move tipo.recnum to idtipo
			
	end
	
		print lote1.recnum				to lotetra.1		// id
		print lote1.codigo				to lotetra.2		// lote
		print lote1.descarrego			to lotetra.3		// sacas
		print lote1.pesooriginal       	to lotetra.4		// peso
		print lote1.qtd					to lotetra.5		// saldo sacas
		print lote1.peso	    		to lotetra.6		// saldo peso
		print lote1.red	     			to lotetra.7		// armazem
		print lote1.quadra  			to lotetra.8		// pilha
		print idtipo					to lotetra.9		// peneira_id
		print idtrans					to lotetra.10		// tracafe_id
		
		calc (total + 1) to total
		
		print total to tela.26
		
		output lotetra

goto iniciolotetra

fimlotetra:
close lote1
close tipo
close trans
