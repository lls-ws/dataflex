open lotao
open gs
open lote1

outfile "osclote.txt"

move 0 to idgs
move 0 to idlote

move 0 to total
move 0 to counter

clear lotao
move data to lotao.data

iniciolotao:
find gt lotao.data
[~found] goto fimlotao
	
	calc (counter + 1) to counter
	
	print counter to tela.15
	
	if lotao.data lt data goto iniciolotao
	if lotao.lote eq "" goto iniciolotao
	
	clear gs
	move lotao.lotao to gs.numero
	find eq gs.numero
	[~found] goto iniciolotao
	[found] move gs.recnum to idgs
	
	clear lote1
	move lotao.lote to lote1.codigo
	find eq lote1.codigo
	[~found] goto iniciolotao
	[found] move lote1.recnum to idlote
	
		print idgs			  	   		to osclote.1		// oscafe_id
		print idlote	  	   			to osclote.2		// lote_id
		print lotao.qtd     			to osclote.3		// sacas
		print lotao.liquido       		to osclote.4		// peso
		
		calc (total + 1) to total
		
		print total to tela.14
		
		output osclote

goto iniciolotao

fimlotao:
close lotao
close gs
close lote1
