open tipo

outfile "tipo.txt"

move 0 to total

iniciopen:
find gt tipo.recnum
[~found] goto fimpen

	print tipo.recnum	     to pen.1
	print tipo.nome     	 to pen.2
	
	calc (total + 1) to total
	
	print total to tela.3
	
	output pen

goto iniciopen

fimpen:
close tipo
