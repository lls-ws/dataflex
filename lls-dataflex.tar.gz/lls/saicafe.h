open gsbx
open fazenda

outfile "saicafe.txt"

move 0 to total
move 0 to counter

clear gsbx
move data to gsbx.data

iniciogsbx:
find gt gsbx.data
[~found] goto fimgsbx
	
	calc (counter + 1) to counter
	
	print counter to tela.19
	
	if gsbx.data lt data goto iniciogsbx
	
	clear fazenda
	move gsbx.dono to fazenda.dono
	
	iniciogsbx2:
	find gt fazenda.dono
	[~found] goto fimgsbx2
		if gsbx.faz ne fazenda.codigo goto iniciogsbx2
		
	fimgsbx2:
	
		print gsbx.recnum  	   		to saicafe.1		// id
		print gsbx.data  	   		to saicafe.2		// data
		print gsbx.numero     		to saicafe.3		// lote
		print gsbx.qtd     			to saicafe.4		// sacas
		print gsbx.liquido       	to saicafe.5		// peso
		print gsbx.sacareal 		to saicafe.6		// sacas saida
		print gsbx.pesoreal			to saicafe.7		// peso saida
		print gsbx.obs2				to saicafe.8		// destino
		print gsbx.obs3     		to saicafe.9		// obs
		print fazenda.recnum		to saicafe.10		// fazenda_id 
		
		calc (total + 1) to total
		
		print total to tela.18
		
		output saicafe

goto iniciogsbx

fimgsbx:
close gsbx
close fazenda
