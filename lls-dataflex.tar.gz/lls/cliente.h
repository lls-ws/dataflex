open cliente

outfile "cliente.txt"

integer fones

move 0 to total
move 0 to fones

iniciocli:
find gt cliente.recnum
[~found] goto fimcli
	
	print cliente.recnum        to cli.1
	print cliente.nome	        to cli.2
	print cliente.endereco      to cli.3
	print cliente.bairro		to cli.4
	print cliente.cidade        to cli.5
	print cliente.est	        to cli.6
	print cliente.cep	        to cli.7
	print cliente.email	        to cli.8
	print cliente.homepage      to cli.9
	print cliente.cgc	        to cli.10
	print cliente.inscr	        to cli.11
	print cliente.obs	        to cli.12
	print cliente.endpgto       to cli.13
	print cliente.pcapgto       to cli.14
	print cliente.fone			to cli.15
	
	calc (total + 1) to total
	
	print total to tela.3
	
	output cli
	
	if cliente.fone ne "" begin
	
		calc (fones + 1) to fones
	
		print fones to tela.4
	
	end

goto iniciocli

fimcli:
close cliente
