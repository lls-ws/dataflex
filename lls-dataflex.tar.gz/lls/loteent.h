open lote1
open tipo
open gci

outfile "loteent.txt"

integer idgci

move 0 to idtipo
move 0 to idgci
move 0 to total
move 0 to counter

clear lote1
move data to lote1.data

inicioloteent:
find gt lote1.data
[~found] goto fimloteent
	
	calc (counter + 1) to counter
	
	print counter to tela.11
	
	if lote1.data lt data goto inicioloteent
	if lote1.tipo eq 0 goto inicioloteent
	if lote1.codigo eq lote1.de goto inicioloteent
	
	clear gci
	move lote1.de to gci.codigo
	find eq gci.codigo
	[~found] goto inicioloteent
	[found] move gci.recnum to idgci
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[~found] goto inicioloteent
	[found] move tipo.recnum to idtipo
	
		print lote1.recnum				to loteent.1		// id
		print lote1.codigo				to loteent.2		// lote
		print lote1.descarrego			to loteent.3		// sacas
		print lote1.pesooriginal       	to loteent.4		// peso
		print lote1.qtd					to loteent.5		// saldo sacas
		print lote1.peso	    		to loteent.6		// saldo peso
		print lote1.red	     			to loteent.7		// armazem
		print lote1.quadra  			to loteent.8		// pilha
		print idtipo					to loteent.9		// peneira_id
		print idgci						to loteent.10		// entcafe_id
		
		calc (total + 1) to total
		
		print total to tela.10
		
		output loteent

goto inicioloteent

fimloteent:
close lote1
close tipo
close gci
