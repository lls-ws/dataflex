open empresa

outfile "guia.txt"

clear empresa
move 1 to empresa.recnum
find eq empresa.recnum
[~found] goto fimgui

	print empresa.ag		to gui.1	// GR
	print empresa.pontser	to gui.2	// OS
	print empresa.pontsai	to gui.3	// GE
	print empresa.pontent	to gui.4	// GT
	
	print empresa.ag		to tela.4
	print empresa.pontser	to tela.5
	print empresa.pontsai	to tela.6
	print empresa.pontent	to tela.7
	
	output gui

fimgui:
close empresa
