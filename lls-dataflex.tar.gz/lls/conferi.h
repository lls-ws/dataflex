open lote1
open tipo
open gci
open gs
open trans

outfile "lote.txt"

integer idcafe excluidos erros

move 0 to idtipo
move 0 to idcafe
move 0 to total
move 0 to counter
move 0 to excluidos
move 0 to erros

clear lote1
move data to lote1.data

iniciolote:
find gt lote1.data
[~found] goto fimlote
	
	calc (counter + 1) to counter
	print counter to tela.6
	
	if lote1.data lt data begin
		calc (excluidos + 1) to excluidos
		print excluidos to tela.4
		goto iniciolote
	end
	if lote1.tipo eq 0 begin
		calc (excluidos + 1) to excluidos
		print excluidos to tela.4
		goto iniciolote
	end
	if lote1.codigo eq lote1.de begin
		calc (excluidos + 1) to excluidos
		print excluidos to tela.4
		goto iniciolote
	end
	
	clear gci
	move lote1.de to gci.codigo
	find eq gci.codigo
	[~found] begin
		
		clear gs
		move lote1.de to gs.numero
		find eq gs.numero
		[~found] begin
			
			clear trans
			move lote1.de to trans.nro
			find eq trans.nro
			[~found] begin
				
				print "Lote nao encontrado!" 	to lote.1
				print lote1.recnum				to lote.2
				print lote1.codigo				to lote.3
				
				output lote
				
				calc (erros + 1) to erros
				print erros to tela.5
				
				goto iniciolote
			
			end
		
		end
	
	end
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[~found] begin
		
		clear tipo
		move lote1.peneira to tipo.nome
		
		iniciotipo:
		find gt tipo.recnum
		[~found] begin
		
			print "Peneira nao encontrada!" to lote.1
			print lote1.recnum				to lote.2
			print lote1.peneira				to lote.3
			print lote1.codigo				to lote.4
			
			output lote

			calc (erros + 1) to erros
			print erros to tela.5
			
			goto iniciolote
			
		end
			
		if lote1.peneira ne tipo.nome goto iniciotipo
			
		goto iniciolote
		
	end
	
	calc (total + 1) to total
	print total to tela.3
	
goto iniciolote

fimlote:
close lote1
close tipo
close gci
close gs
close trans
