///////// criado para zerar o saldo das fazendas em negativo (20/05/2010)
clear fazenda

inicio_fazenda:
find gt fazenda.recnum
[not found] goto fim_fazenda
    if fazenda.estoque lt 0 begin
	reread
	    move 0 to fazenda.estoque
    	    saverecord fazenda
        unlock
    end
goto inicio_fazenda

fim_fazenda:
clear fazenda

clear cliente

inicio_cliente:
find gt cliente.recnum
[not found] goto fim_cliente
    if cliente.saldo lt 0 begin
	reread
	    move 0 to cliente.saldo
    	    saverecord cliente
        unlock
    end
goto inicio_cliente

fim_cliente:
clear cliente
/////////////////// fim da alteracao ///////////////
