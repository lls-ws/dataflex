open lote1
open tipo
open gci

outfile "lote.txt"

integer idtipo idgci

move 0 to total
move 0 to counter

iniciolote:
find gt lote1.recnum
[~found] goto fimlote
	
	calc (counter + 1) to counter
	
	print counter to tela.8
	
	if lote1.data lt data goto iniciolote
	if lote1.gui ne "GR" goto iniciolote
	if lote1.tipo eq 0 goto iniciolote
	
	clear gci
	move lote1.de to gci.codigo
	find eq gci.codigo
	[~found] goto iniciolote
	[found] move gci.recnum to idgci
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[~found] goto iniciolote
	[found] move tipo.recnum to idtipo
	
		print lote1.recnum				to lot.1		// id
		print lote1.codigo				to lot.2		// lote
		print lote1.descarrego			to lot.3		// sacas
		print lote1.pesooriginal       	to lot.4		// peso
		print lote1.qtd					to lot.5		// saldoSacas
		print lote1.peso	    		to lot.6		// saldoPeso
		print lote1.red	     			to lot.7		// armazem
		print lote1.quadra  			to lot.8		// pilha
		print idtipo					to lot.9		// peneira_id
		print idgci						to lot.10		// entcafe_id
		
		calc (total + 1) to total
		
		print total to tela.7
		
		output lot

goto iniciolote

fimlote:
close lote1
close tipo
close gci
