integer qtd codcli 
integer entradas saidas saldo
integer entradas_renato saidas_renato saldo_renato
integer saldo_diferenca saldo_total
string obs

open entmilho
open saimilho
open milho

move 0 to qtd
move 0 to saldo_total

move tela.3 to codcli

outfile "renato.txt"

print "Verificando Saldo..." to tela.6

inicio:
find gt milho.recnum
[~found] goto fim

	calc (qtd + 1) to qtd

	print qtd to tela.5

	if codcli ne 0 begin
		if milho.cliente ne codcli goto inicio
	end
	
move 0 to entradas
move 0 to saidas
move 0 to saldo

move 0 to entradas_renato
move 0 to saidas_renato
move 0 to saldo_renato

move 0 to saldo_diferenca

// Entradas
clear entmilho
move milho.cliente to entmilho.cliente

print "Totalizando Entradas..." to tela.6

inicio2:
find gt entmilho.cliente
[not found] goto fim2
	
	calc (qtd + 1) to qtd

	print qtd to tela.5
	
	if entmilho.faz ne milho.faz goto inicio2
    if entmilho.cliente ne milho.cliente goto fim2
    
	calc (entradas+entmilho.liquido) to entradas
	
goto inicio2

fim2:
	
// Saidas
clear saimilho
move milho.cliente to saimilho.cliente

print "Totalizando Saidas..." to tela.6

inicio3:
find gt saimilho.cliente
[not found] goto fim3
	
	calc (qtd + 1) to qtd

	print qtd to tela.5
	
	if saimilho.faz ne milho.faz goto inicio3
    if saimilho.cliente ne milho.cliente goto fim3
    
	calc (saidas+saimilho.liquido) to saidas
	
goto inicio3

fim3:
	
	// Atualizando Saldo
	calc (entradas-saidas) 	to saldo
	
	move milho.peso			to entradas_renato
	move milho.quant 		to saidas_renato
	move milho.total 		to saldo_renato
	
	print milho.nome 		to nome.1
	
	print entradas_renato	to ficha.1
	print saidas_renato		to ficha.2
	print saldo_renato		to ficha.3
	
	print entradas			to resumo.1
	print saidas			to resumo.2
	print saldo				to resumo.3
	
	output nome
	output ficha
	output resumo
	
	calc (saldo-saldo_renato) to saldo_diferenca
	
	if saldo_diferenca ne 0 begin
		
		print "Saldo Errado! Atualizando Ficha!!!" to tela.6
		print "Saldo Errado! Atualizando Ficha!!!" to msg.1
		
		output msg
		
		print saldo_renato			to total.1
		print saldo					to total.2
		print saldo_diferenca		to total.3
		
		output total
		
		move "Acerto de Saldo" to obs
		
		// Inserindo Saida para acerto de saldo
		clear saimilho
		reread
			move tela.2	 				to saimilho.data
			move saldo_diferenca  		to saimilho.liquido
			move obs				 	to saimilho.obs
			move milho.faz				to saimilho.faz
			move milho.nome				to saimilho.nome
			move milho.cliente 			to saimilho.cliente
		saverecord saimilho
		unlock
		
		calc (saidas+saldo_diferenca) to saidas
		
	end
	
	// Atualizando Ficha
	reread
		move entradas 		to milho.peso
		move saidas			to milho.quant
	saverecord milho
	unlock
	
	print milho.peso		to final.1
	print milho.quant		to final.2
	print milho.total		to final.3
	
	output final
	
	print "Saldo correto! Ficha Atualizada!!!" to tela.6
	print "Saldo correto! Ficha Atualizada!!!\n" to msg.1
	
	output msg
	
	calc (saldo_total+entradas-saidas) to saldo_total
	
goto inicio

fim:
print saldo_total to final2.1

output final2

print "Rotina executada com sucesso!" to tela.6
