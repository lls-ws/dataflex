open saimilho
open fazenda

outfile "saimilho.txt"

move 0 to total
move 0 to counter

iniciosaimilho:
find gt saimilho.recnum
[~found] goto fimsaimilho
	
	calc (counter + 1) to counter
	
	print counter to tela.14
	
	if saimilho.data lt data goto iniciosaimilho
	
	clear fazenda
	move saimilho.cliente to fazenda.dono
	
	iniciosaimilho2:
		find gt fazenda.dono
		[~found] goto fimsaimilho2
		if saimilho.faz ne fazenda.codigo goto iniciosaimilho2  
		
	fimsaimilho2:
	
		print saimilho.data     	to saimil.1
		print saimilho.laudo     	to saimil.2
		print saimilho.tiket     	to saimil.3
		print saimilho.placa       	to saimil.4
		print saimilho.liquido     	to saimil.5
		print saimilho.obs	     	to saimil.6
		print saimilho.cilo     	to saimil.7
		print fazenda.recnum		to saimil.8
		
		calc (total + 1) to total
		
		print total to tela.12
		
		output saimil

goto iniciosaimilho

fimsaimilho:
close saimilho
close fazenda
