open azul
move 0 to qtd
move 0 to qtd2

print "azul" to tela.4
print qtd to tela.5
print qtd to tela.6

inicio_azul:
find gt azul.recnum
[not found] goto fim_azul
    inkey$ tecla
    if tecla eq "q" goto termina
    
    if azul.data gt tela.1 begin
	calc (qtd2 + 1) to qtd2
	print qtd2 to tela.6
	goto inicio_azul
    end    
    
    reread
	calc (qtd + 1) to qtd
	print qtd to tela.5
	delete azul
    unlock
    
goto inicio_azul

fim_azul: