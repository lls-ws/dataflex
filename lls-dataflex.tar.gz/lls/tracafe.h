open trans
open fazenda

outfile "tracafe.txt"

integer idfaz idfaz2

move 0 to total
move 0 to counter

clear trans
move data to trans.dato

iniciotrans:
find gt trans.dato
[~found] goto fimtrans
	
	calc (counter + 1) to counter
	
	print counter to tela.23
	
	if trans.dato lt data goto iniciotrans
	
	clear fazenda
	move trans.dono to fazenda.dono
	
	iniciotrans2:
	find gt fazenda.dono
	[~found] goto fimtrans2
	[found] move fazenda.recnum to idfaz
		if trans.faz ne fazenda.codigo goto iniciotrans2
		
	fimtrans2:
	
	clear fazenda
	move trans.novodono to fazenda.dono
	
	iniciotrans3:
	find gt fazenda.dono
	[~found] goto fimtrans3
	[found] move fazenda.recnum to idfaz2
		if trans.novafaz ne fazenda.codigo goto iniciotrans3
		
	fimtrans3:
	
		print trans.recnum  	to tracafe.1		// id
		print trans.data  	   	to tracafe.2		// data
		print trans.nro		    to tracafe.3		// lote
		print trans.qtd     	to tracafe.4		// sacas
		print trans.peso       	to tracafe.5		// peso
		print trans.obs1     	to tracafe.6		// obs
		print idfaz				to tracafe.7		// fazenda_id
		print idfaz2			to tracafe.8		// fazendaDestino_id
		
		calc (total + 1) to total
		
		print total to tela.22
		
		output tracafe

goto iniciotrans

fimtrans:
close trans
close fazenda
