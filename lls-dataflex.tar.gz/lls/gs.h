open gs
open servico
open fazenda

outfile "oscafe.txt"

move 0 to total
move 0 to counter

clear gs
move data to gs.data

iniciogs:
find gt gs.data
[~found] goto fimgs
	
	calc (counter + 1) to counter
	
	print counter to tela.13
	
	if gs.data lt data goto iniciogs
	
	clear fazenda
	move gs.dono to fazenda.dono
	
	iniciogs2:
	find gt fazenda.dono
	[~found] goto fimgs2
		if gs.faz ne fazenda.codigo goto iniciogs2
		
	fimgs2:
	
	clear servico
	move gs.lote to servico.lotao
	find eq servico.lotao
	[~found] goto iniciogs
	
		print gs.recnum  	   		to oscafe.1		// id
		print gs.data  	   			to oscafe.2		// data
		print gs.lote	     		to oscafe.3		// lote
		print gs.qtd     			to oscafe.4		// sacas
		print gs.liquido       		to oscafe.5		// peso
		print servico.quebra		to oscafe.6		// sacas quebra
		print servico.pesoq			to oscafe.7		// peso quebra
		print servico.acrescimo 	to oscafe.8		// sacas acrescimo
		print servico.pacres		to oscafe.9		// peso acrescimo
		print gs.autorizacao		to oscafe.10	// autorizacao
		print servico.obs1			to oscafe.11	// instrucoes
		print servico.obs2			to oscafe.12	// instrucoes
		print servico.obs3			to oscafe.13	// instrucoes
		print servico.obs4     		to oscafe.14	// obs
		print servico.obs5     		to oscafe.15	// obs
		print servico.obs6     		to oscafe.16	// obs
		print fazenda.recnum		to oscafe.17	// fazenda_id 
		
		calc (total + 1) to total
		
		print total to tela.12
		
		output oscafe

goto iniciogs

fimgs:
close gs
close servico
close fazenda
