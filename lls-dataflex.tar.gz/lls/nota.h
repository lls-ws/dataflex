open nota
move 0 to qtd
move 0 to qtd2

print "nota" to tela.4
print qtd to tela.5
print qtd to tela.6

inicio_nota:
find gt nota.recnum
[not found] goto fim_nota
    inkey$ tecla
    if tecla eq "q" goto termina
    
    if nota.data gt tela.1 begin
	calc (qtd2 + 1) to qtd2
	print qtd2 to tela.6
	goto inicio_nota
    end    
    
    reread
	calc (qtd + 1) to qtd
	print qtd to tela.5
	delete nota
    unlock
    
goto inicio_nota

fim_nota: