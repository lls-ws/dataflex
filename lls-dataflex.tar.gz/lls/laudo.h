open dadosfe

outfile "laudo.txt"

clear dadosfe
move 1 to dadosfe.recnum
find eq dadosfe.recnum
[~found] goto fimlaudo

	print dadosfe.laudo	 	    to laudo.1
	
	print dadosfe.laudo			to tela.3
	
	output laudo

fimlaudo:
close dadosfe
