open trans1
move 0 to qtd
move 0 to qtd2

print "trans1" to tela.4
print qtd to tela.5
print qtd to tela.6

inicio_trans1:
find gt trans1.recnum
[not found] goto fim_trans1
    inkey$ tecla
    if tecla eq "q" goto termina
    
    if trans1.data gt tela.1 begin
	calc (qtd2 + 1) to qtd2
	print qtd2 to tela.6
	goto inicio_trans1
    end    
    
    reread
	calc (qtd + 1) to qtd
	print qtd to tela.5
	delete trans1
    unlock
    
goto inicio_trans1

fim_trans1: