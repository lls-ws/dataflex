open lote1
open tipo
open gci

outfile "lotegr.txt"

integer idgci

move 0 to idtipo
move 0 to idgci
move 0 to total
move 0 to counter

clear lote1
move data to lote1.data

iniciolotegr:
find gt lote1.data
[~found] goto fimlotegr
	
	calc (counter + 1) to counter
	
	print counter to tela.11
	
	if lote1.data lt data goto iniciolotegr
	if lote1.gui ne "GR" goto iniciolotegr
	if lote1.tipo eq 0 goto iniciolotegr
	
	clear gci
	move lote1.de to gci.codigo
	find eq gci.codigo
	[~found] goto iniciolotegr
	[found] move gci.recnum to idgci
	
	clear tipo
	move lote1.tipo to tipo.codigo
	find eq tipo.codigo
	[~found] goto iniciolotegr
	[found] move tipo.recnum to idtipo
	
		print lote1.recnum				to lot.1		// id
		print lote1.codigo				to lot.2		// lote
		print lote1.descarrego			to lot.3		// sacas
		print lote1.pesooriginal       	to lot.4		// peso
		print lote1.qtd					to lot.5		// saldo sacas
		print lote1.peso	    		to lot.6		// saldo peso
		print lote1.red	     			to lot.7		// armazem
		print lote1.quadra  			to lot.8		// pilha
		print idtipo					to lot.9		// peneira_id
		print idgci						to lot.10		// entcafe_id
		
		calc (total + 1) to total
		
		print total to tela.10
		
		output lot

goto iniciolotegr

fimlotegr:
close lote1
close tipo
close gci
