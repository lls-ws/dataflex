/*
open fazenda
open cliente

integer saldo_fazenda saldo_cliente

move 0 to saldo_fazenda
move 0 to saldo_cliente

inicio:
find gt fazenda.recnum
[not found] goto fim
    if fazenda.estoque lt 0 show "*"
    calc (saldo_fazenda + fazenda.estoque) to saldo_fazenda
goto inicio

fim:
show "Saldo Fazenda: " saldo_fazenda

inicio2:
find gt cliente.recnum
[not found] goto fim2
    if cliente.saldo lt 0 show "*"
    calc (saldo_cliente + cliente.saldo) to saldo_cliente
goto inicio2

fim2:
show " - Saldo Cliente " saldo_cliente
abort