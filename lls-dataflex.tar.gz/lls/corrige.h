open lote1
open gci
open trans1
open saidas
open gsbx
open gs
open lotao
open cliente
open fazenda
open servico
open trans
open servico1
open tabela

integer contador

print "Corrigindo Dados" to tela.2

move 0 to contador

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 11085 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 11086 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear tabela
move 31 to tabela.recnum
find eq tabela.recnum
[found] begin

	reread
	move "SAIDA CAFE ENSACADO P/GRANEL" to tabela.descricao
	saverecord tabela
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear tabela
move 18 to tabela.recnum
find eq tabela.recnum
[found] begin

	reread
	move "DESCARGA CAFE ENSACADO" to tabela.descricao
	saverecord tabela
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear tabela
move 25 to tabela.recnum
find eq tabela.recnum
[found] begin

	reread
	move "CARGA CAF ENSACADO" to tabela.descricao
	saverecord tabela
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 10113 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 280 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 6174 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 1104 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	delete servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 10964 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "A42" to servico1.servico
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 6099 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 6032 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5927 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5832 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5721 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5429 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5571 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5312 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear servico1
move 5372 to servico1.recnum
find eq servico1.recnum
[found] begin

	reread
	move "*" to servico1.flag
	saverecord servico1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR006264/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 71 to lote1.descarrego
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR006264" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 71 to lote1.descarrego
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "GR006264" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	move 71 to gci.des
	move 71 to gci.qtd
	saverecord gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

move 0 to contador
clear lote1
move "" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001268/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001268/B" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001268/C" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gs
move "OS001268" to gs.numero
find eq gs.numero
[found] begin

	reread
	delete gs
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001257/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001257/B" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "OS001257/C" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gs
move "OS001257" to gs.numero
find eq gs.numero
[found] begin

	reread
	delete gs
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gsbx
move "GE001342" to gsbx.numero
find eq gsbx.numero
[found] begin

	reread
	delete gsbx
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear saidas
move 4241 to saidas.recnum
find eq saidas.recnum
[found] begin

	reread
	delete saidas
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear saidas
move 4242 to saidas.recnum
find eq saidas.recnum
[found] begin

	reread
	delete saidas
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR002966/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "GR002966" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR000008/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	delete lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lotao
move 1341 to lotao.recnum
find eq lotao.recnum
[found] begin

	reread
	move "*" to lotao.flag
	saverecord lotao
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GT000155/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 33 to lote1.tipo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GT000158/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 33 to lote1.tipo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GT000229/A" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 34 to lote1.tipo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "OS001217" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "GT000842" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "GT000829" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gci
move "GT000904" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end
  
calc (contador + 1) to contador
print contador to tela.3
  
clear gci
move "GT000931" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3
  
clear gci
move "GT001136" to gci.codigo
find eq gci.codigo
[found] begin

	reread
	delete gci
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR002720" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move 3 			  to lote1.tipo
	move "GR002720/A" to lote1.codigo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear trans1
move 34 to trans1.recnum
find eq trans1.recnum
[found] begin

	reread
	move "GR002720/A" to trans1.lote
	saverecord trans1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GR002702" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move "GR002702/A" to lote1.codigo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear saidas
move 3021 to saidas.recnum
find eq saidas.recnum
[found] begin

	reread
	move "GR002702/A" to saidas.lote
	saverecord saidas
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear lote1
move "GT001136" to lote1.codigo
find eq lote1.codigo
[found] begin

	reread
	move "GT001136/A" to lote1.codigo
	saverecord lote1
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear saidas
move 7906 to saidas.recnum
find eq saidas.recnum
[found] begin

	reread
	move "GT001136/A" to saidas.lote
	saverecord saidas
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear saidas
move 296 to saidas.recnum
find eq saidas.recnum
[found] begin

	reread
	move "GT000904/A" to saidas.lote
	saverecord saidas
    unlock
	
end

calc (contador + 1) to contador
print contador to tela.3

clear gsbx
move "GR003904" to gsbx.numero
find eq gsbx.numero
[found] begin

	reread
	delete gsbx
	unlock
	
end

/////// fechando todos lotes a sair
move 0 to contador

print "Fechando Lotes a sair" to tela.2

clear saidas

inicio2:
find gt saidas.recnum
[~found] goto fim2
	calc (contador + 1) to contador
	print contador to tela.3
	
	if saidas.flag eq "*" goto inicio2
	
	reread
	move "*" to saidas.flag
	saverecord saidas
    unlock

goto inicio2

fim2:

///////////// CORRECAO LOTES DE SAIDA ////////////////////////
integer quantidade alterados excluidos excluir

print "Correcao de Saida" to tela.2

move 0 to contador
move 0 to quantidade
move 0 to alterados
move 0 to excluidos
move 0 to excluir

open gsbx
open saidas

clear gsbx

inicio:
find gt gsbx.recnum
[~found] goto fim
	
	calc (contador + 1) to contador
	print contador to tela.3
	
	if gsbx.data eq "" begin
	
		move 1 to excluir
	
		calc (quantidade + 1) to quantidade
		print quantidade to tela.4
		
		clear saidas
		move gsbx.numero to saidas.saida
		
		iniciosaida:
		find gt saidas.saida
		[~found] begin
		
			calc (contador + 1) to contador
			print contador to tela.3
		
			if gsbx.qtd le 0 begin
			
				calc (excluidos + 1) to excluidos
				print excluidos to tela.6
			
				reread
				delete gsbx
				unlock
			
			end
		
			goto inicio
		
		end
			
			if gsbx.numero eq saidas.saida begin
				
				reread
				move saidas.data					to gsbx.data
				calc (gsbx.qtd+saidas.qtd) 			to gsbx.qtd
				calc (gsbx.liquido+saidas.liquido) 	to gsbx.liquido
				saverecord gsbx
				unlock
				
				calc (alterados + 1) to alterados
				print alterados to tela.5
				
				move 0 to excluir
				
				goto iniciosaida
				
			end
		
		if excluir eq 1 begin
		
			reread
			delete gsbx
			unlock
			
		end
			
	end
	
goto inicio
	
fim:

/////////// Zerando o valor do saldo inicial dos clientes e fazendas
print "Zerando Clientes" to tela.2

move 0 to contador
clear cliente

iniciocli:
find gt cliente.recnum
[~found] goto fimcli

	calc (contador + 1) to contador
	print contador to tela.3
	
	reread
	move 0 to cliente.vlr1			// entradas
	move 0 to cliente.vlr2			// saidas
	move 0 to cliente.vlr3			// quebra
	move 0 to cliente.vlr4			// acrescimo
	move 0 to cliente.vlr5			// transferencia recebidas
	move 0 to cliente.vlr6			// transferencias emitidas
	move 0 to cliente.saldo			// saldo inicial
	move 0 to cliente.valor2		// saldo atual
	saverecord cliente
    unlock

goto iniciocli

fimcli:

print "Zerando Fazendas" to tela.2

move 0 to contador
clear fazenda

inicio_faz:
find gt fazenda.recnum
[not found] goto fim_faz
	
	calc (contador + 1) to contador
	print contador to tela.3
	
	reread
	move 0 to fazenda.estoque		// saldo inicial
	move 0 to fazenda.saca			// saldo atual
    saverecord fazenda
    unlock

goto inicio_faz

fim_faz:

/////////// Calculando o valor do saldo atual das fazendas e clientes
integer contador1 contador2 contlote contlote2
string datalote

print "Saldo Atual" to tela.2

move 0 to contador
move 0 to contlote
move 0 to contlote2

move "01/02/2012" to datalote

clear lote1
move datalote to lote1.data

inicio_lote:
find gt lote1.data
[~found] goto fim_lote
	
	calc (contador + 1) to contador
	print contador to tela.3
	
	if lote1.qtd eq 0 goto inicio_lote
	
	calc (lote1.qtd + contlote2) to contlote2
	print contlote2 to tela.6
	
	clear cliente
	move lote1.dono to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (lote1.qtd + cliente.valor2) to cliente.valor2
		saverecord cliente
		unlock
			
		clear fazenda
		move cliente.codigo to fazenda.dono
		
		inicio_fazenda:
		find gt fazenda.dono
		[~found] goto inicio_lote
			if fazenda.dono gt cliente.codigo goto inicio_lote
			if fazenda.codigo ne lote1.faz goto inicio_fazenda
				
				calc (contador1 + 1) to contador1
				print contador1 to tela.5
				
				reread
				calc (lote1.qtd + fazenda.saca) to fazenda.saca
				calc (lote1.qtd + fazenda.estoque) to fazenda.estoque
				saverecord fazenda
				unlock
				
				calc (lote1.qtd + contlote) to contlote
				print contlote to tela.2
				
	end
	
goto inicio_lote

fim_lote:

//////////////////////// Calculando as Entradas das fazendas e clientes
move 0 to contador
move 0 to contlote
move 0 to contlote2

move "01/09/2018" to datalote

print "Entradas" to tela.2

clear gsbx

move datalote to gci.data

inicio_gci:
find gt gci.data
[~found] goto fim_gci
	if gci.flag eq "*" goto inicio_gci

	clear cliente
	move gci.dono to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (cliente.vlr1 + gci.qtd) to cliente.vlr1
		saverecord cliente
		unlock
	end
	
	clear fazenda
	move cliente.codigo to fazenda.dono
	
	inicio_fazenda_gci:
	find gt fazenda.dono
	[~found] goto inicio_gci
		if fazenda.dono gt cliente.codigo goto inicio_gci
		if fazenda.codigo ne gci.faz goto inicio_fazenda_gci
			
			calc (contador1 + 1) to contador1
			print contador1 to tela.5
			
			reread
			calc (fazenda.estoque - gci.qtd) to fazenda.estoque
			saverecord fazenda
			unlock
			
			calc (gci.qtd + contlote) to contlote
			print contlote to tela.3

goto inicio_gci

fim_gci:

//////////////////////// Calculando as Saidas das fazendas e clientes
move 0 to contador
move 0 to contlote
move 0 to contlote2

print "Saidas" to tela.2

clear gsbx

move datalote to gsbx.data

inicio_gsbx:
find gt gsbx.data
[~found] goto fim_gsbx
	if gsbx.flag eq "*" goto inicio_gsbx

	clear cliente
	move gsbx.dono to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (cliente.vlr2 + gsbx.qtd) to cliente.vlr2
		saverecord cliente
		unlock
	end
	
	clear fazenda
	move cliente.codigo to fazenda.dono
	
	inicio_fazenda_gsbx:
	find gt fazenda.dono
	[~found] goto inicio_gsbx
		if fazenda.dono gt cliente.codigo goto inicio_gsbx
		if fazenda.codigo ne gsbx.faz goto inicio_fazenda_gsbx
			
			calc (contador1 + 1) to contador1
			print contador1 to tela.5
			
			reread
			calc (fazenda.estoque + gsbx.qtd) to fazenda.estoque
			saverecord fazenda
			unlock
			
			calc (gsbx.qtd + contlote) to contlote
			print contlote to tela.3

goto inicio_gsbx

fim_gsbx:

//////////////////////// Calculando os Servicos das fazendas e clientes
move 0 to contador
move 0 to contlote
move 0 to contlote2

print "Servicos" to tela.2

clear servico

move datalote to servico.data

inicio_servico:
find gt servico.data
[~found] goto fim_servico
	if servico.flag eq "*" goto inicio_servico

	clear cliente
	move servico.cliente to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (cliente.vlr3 + servico.quebra)    to cliente.vlr3
		calc (cliente.vlr4 + servico.acrescimo) to cliente.vlr4
		saverecord cliente
		unlock
	end
	
	clear fazenda
	move cliente.codigo to fazenda.dono
	
	inicio_fazenda_servico:
	find gt fazenda.dono
	[~found] goto inicio_servico
		if fazenda.dono gt cliente.codigo goto inicio_servico
		if fazenda.codigo ne servico.faz goto inicio_fazenda_servico
			
			calc (contador1 + 1) to contador1
			print contador1 to tela.5
			
			reread
			calc (fazenda.estoque - servico.acrescimo + servico.quebra) to fazenda.estoque
			saverecord fazenda
			unlock
			
			calc (servico.acrescimo - servico.quebra + contlote) to contlote
			print contlote to tela.3

goto inicio_servico

fim_servico:

//////////////////////// Calculando as Transferencias das fazendas e clientes
move 0 to contador
move 0 to contlote
move 0 to contlote2

print "Transferencias" to tela.2

clear trans

move datalote to trans.dato

inicio_trans:
find gt trans.dato
[~found] goto fim_trans
	if trans.flag2 eq "*" goto inicio_trans

	clear cliente
	move trans.dono to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (cliente.vlr6 + trans.qtd) to cliente.vlr6		// transferencia emitidas
		saverecord cliente
		unlock
	end
	
	clear fazenda
	move cliente.codigo to fazenda.dono
	
	inicio_fazenda_trans:
	find gt fazenda.dono
	[~found] goto fim_fazenda_trans
		if fazenda.dono gt cliente.codigo goto fim_fazenda_trans
		if fazenda.codigo ne trans.faz goto inicio_fazenda_trans
			
			calc (contador1 + 1) to contador1
			print contador1 to tela.5
			
			reread
			calc (fazenda.estoque + trans.qtd) to fazenda.estoque
			saverecord fazenda
			unlock
			
			calc (trans.qtd + contlote) to contlote
			print contlote to tela.3

	fim_fazenda_trans:
	
	clear cliente
	move trans.novodono to cliente.codigo
	find eq cliente.codigo
	[found] begin
		
		calc (contador2 + 1) to contador2
		print contador2 to tela.4
		
		reread
		calc (cliente.vlr5 + trans.sacareal) to cliente.vlr5	// transferencia recebidas
		saverecord cliente
		unlock
	end
	
	clear fazenda
	move cliente.codigo to fazenda.dono
	
	inicio_fazenda_trans2:
	find gt fazenda.dono
	[~found] goto inicio_trans
		if fazenda.dono gt cliente.codigo goto inicio_trans
		if fazenda.codigo ne trans.novafaz goto inicio_fazenda_trans2
			
			calc (contador1 + 1) to contador1
			print contador1 to tela.5
			
			reread
			calc (fazenda.estoque - trans.sacareal) to fazenda.estoque
			saverecord fazenda
			unlock
			
			calc (trans.sacareal - contlote) to contlote
			print contlote to tela.3

goto inicio_trans

fim_trans:

/////////// Calculando o valor do saldo inicial dos clientes e fazendas
print "Calculando saldo inicial" to tela.2

integer saldo

move 0 to contador
move 0 to contlote
move 0 to saldo

clear cliente

iniciocli2:
find gt cliente.recnum
[~found] goto fimcli2

	calc (contador + 1) to contador
	print contador to tela.3
	
	reread
	calc (cliente.valor2-cliente.vlr1+cliente.vlr2+cliente.vlr3-cliente.vlr4-cliente.vlr5+cliente.vlr6) to cliente.saldo
	saverecord cliente
    unlock
    
    calc (cliente.saldo + contlote) to contlote
	print contlote to tela.5

goto iniciocli2

fimcli2:

move 0 to contador
move 0 to contlote

clear fazenda

inicio_faz2:
find gt fazenda.recnum
[not found] goto fim_faz2
	
	calc (contador + 1) to contador
	print contador to tela.3
	
	calc (fazenda.estoque + contlote) to contlote
	print contlote to tela.4
	
	reread
	move "30/09/2018" to fazenda.dataescri
	saverecord fazenda
    unlock
	
goto inicio_faz2

fim_faz2:

/////////// Fechando os banco de dados
close lote1
close gci	
close trans1
close saidas
close gsbx
close gs
close lotao
close cliente
close fazenda
close servico
close trans
close servico1
close tabela

close_output
