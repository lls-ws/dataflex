open umidade
open tabela2

outfile "umidade.txt"

move 0 to total

inicioumi:
find gt umidade.recnum
[~found] goto fimumi

	print umidade.recnum        to umi.1
	print umidade.codigo        to umi.2
	print umidade.desconto      to umi.3
	
	clear tabela2
	move umidade.codigo to tabela2.codigo
	find eq tabela2.codigo
	print tabela2.valor			to umi.4
	
	calc (total + 1) to total
	
	print total to tela.2
	
	output umi

goto inicioumi

fimumi:
close umidade
close tabela2
