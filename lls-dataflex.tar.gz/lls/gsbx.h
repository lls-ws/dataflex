open gsbx
open fazenda

outfile "saicafe.txt"

move 0 to total
move 0 to counter

clear gsbx
move data to gsbx.data

iniciogsbx:
find gt gsbx.data
[~found] goto fimgsbx
	
	calc (counter + 1) to counter
	
	print counter to tela.19
	
	if gsbx.data lt data goto iniciogsbx
	
	clear fazenda
	move gsbx.dono to fazenda.dono
	
	iniciogsbx2:
	find gt fazenda.dono
	[~found] goto fimgsbx2
		if gsbx.faz ne fazenda.codigo goto iniciogsbx2
		
	fimgsbx2:
	
		print gsbx.recnum  	   		to saicaf.1		// id
		print gsbx.data  	   		to saicaf.2		// data
		print gsbx.lote	     		to saicaf.3		// lote
		print gsbx.qtd     			to saicaf.4		// sacas
		print gsbx.liquido       	to saicaf.5		// peso
		print gsbx.sacareal 		to saicaf.6		// sacas saida
		print gsbx.pesoreal			to saicaf.7		// peso saida
		print gsbx.obs2				to saicaf.8		// destino
		print gsbx.obs3     		to saicaf.9		// obs
		print fazenda.recnum		to saicaf.10	// fazenda_id 
		
		calc (total + 1) to total
		
		print total to tela.18
		
		output saicaf

goto iniciogsbx

fimgsbx:
close gsbx
close fazenda
